chrome.runtime.onInstalled.addListener(() => {
    chrome.storage.sync.set({
        twitter: {
            apikey: null,
            apikeysecret: null,
            accesstoken: null,
            accesstokensecret: null
        }
    });
});